namespace styleshareCategories_platform.CategoryService.Interfaces.Rest.Resources;

public record UpdateCategoryResource(string Name, string Description, bool IsFavorite, string Tipo);
