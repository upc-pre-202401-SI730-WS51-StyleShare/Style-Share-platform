namespace styleshareCategories_platform.CategoryService.Interfaces.Rest.Resources;

public record CreateCategoryResource(int Id, string Name, string Description, bool IsFavorite, string Tipo);