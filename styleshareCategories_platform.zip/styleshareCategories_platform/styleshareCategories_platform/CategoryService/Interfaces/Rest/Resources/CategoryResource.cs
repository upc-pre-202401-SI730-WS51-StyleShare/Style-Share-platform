namespace styleshareCategories_platform.CategoryService.Interfaces.Rest.Resources;

public record CategoryResource(int Id, string Name, string Description, bool IsFavorite, string Tipo );