using styleshareCategories_platform.CategoryService.Domain.Model.Entities;
using styleshareCategories_platform.CategoryService.Interfaces.Rest.Resources;

namespace styleshareCategories_platform.CategoryService.Interfaces.Rest.Trasform;

public static class CategoryResourceFromEntityAssembler
{
    public static CategoryResource ToResourceFromEntity(Category entity)
    {
        return new CategoryResource(entity.Id, entity.Name, entity.Description, entity.IsFavorite, entity.Tipo);
    }
}