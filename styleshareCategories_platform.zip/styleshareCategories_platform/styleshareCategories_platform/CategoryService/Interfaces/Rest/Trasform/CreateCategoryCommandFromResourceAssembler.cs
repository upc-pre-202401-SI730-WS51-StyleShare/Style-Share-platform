using styleshareCategories_platform.CategoryService.Domain.Model.Commands;
using styleshareCategories_platform.CategoryService.Interfaces.Rest.Resources;

namespace styleshareCategories_platform.CategoryService.Interfaces.Rest.Trasform;

public static class CreateCategoryCommandFromResourceAssembler
{
    public static CreateCategoryCommand ToCommandFromResource(CreateCategoryResource resource)
    {
        return new CreateCategoryCommand(
            resource.Id,
            resource.Name,
            resource.Description,
            resource.IsFavorite,
            resource.Tipo
        );
    }

}