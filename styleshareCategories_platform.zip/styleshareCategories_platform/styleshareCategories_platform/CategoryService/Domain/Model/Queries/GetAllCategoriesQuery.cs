namespace styleshareCategories_platform.CategoryService.Domain.Model.Queries;

public record GetAllCategoriesQuery();