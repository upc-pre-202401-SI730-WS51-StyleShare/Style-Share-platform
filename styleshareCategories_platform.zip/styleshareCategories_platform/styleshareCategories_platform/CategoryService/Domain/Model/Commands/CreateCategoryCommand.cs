namespace styleshareCategories_platform.CategoryService.Domain.Model.Commands;

public record CreateCategoryCommand(int Id, string Name, string Description, bool IsFavorite, string Tipo );
