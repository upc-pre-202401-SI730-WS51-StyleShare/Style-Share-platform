namespace styleshareCategories_platform.CategoryService.Domain.Model.Commands;

public record DeleteCategoryByIdCommand(int CategoryId);
