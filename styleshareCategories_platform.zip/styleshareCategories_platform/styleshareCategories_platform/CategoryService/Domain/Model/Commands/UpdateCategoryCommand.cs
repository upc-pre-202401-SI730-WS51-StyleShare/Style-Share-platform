namespace styleshareCategories_platform.CategoryService.Domain.Model.Commands;

public class UpdateCategoryCommand
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public bool IsFavorite { get; set; }
    public string Tipo { get; set; }

    
    public UpdateCategoryCommand(string Name, string Description, bool IsFavorite, string Tipo)
    {
        Name = Name;
        Description = Description;
        IsFavorite = IsFavorite;
        Tipo = Tipo;
    }

    public UpdateCategoryCommand()
    {
        
    }
}