using styleshareCategories_platform.CategoryService.Domain.Model.Commands;
using styleshareCategories_platform.CategoryService.Domain.Model.Entities;
using styleshareCategories_platform.CategoryService.Domain.Repositories;
using styleshareCategories_platform.CategoryService.Domain.Services;
using styleshareCategories_platform.Shared.Domain.Repositories;

namespace styleshareCategories_platform.CategoryService.Application.Internal.CommandService;

public class CategoryCommandService(ICategoryRepository categoryRepository, IUnitOfWork unitOfWork) : ICategoryCommandService
{
    public async Task<Category?> Handle(CreateCategoryCommand command)
    {
        var category = new Category
        {
            Id = command.Id,
            Name = command.Name,
            Description = command.Description,
            IsFavorite = command.IsFavorite,
            Tipo = command.Tipo
        };

        await categoryRepository.AddCategoryAsync(category);
        return category;
    }

    public async Task<Category?> Handle(DeleteCategoryByIdCommand command)
    {
        var category = await categoryRepository.GetCategoryByIdAsync(command.CategoryId);
        if (category == null)
        {
            return null;
        }

        await categoryRepository.DeleteCategoryAsync(category.Id);
        return category;
    }
    public async Task<Category?> Handle(UpdateCategoryCommand command)
    {
        var category = await categoryRepository.GetCategoryByIdAsync(command.Id);
        if (category == null)
        {
            return null; 
        }
        
        category.Name = command.Name;
        category.Description = command.Description;
        category.IsFavorite = command.IsFavorite;
        category.Tipo = command.Tipo;

        await categoryRepository.UpdateCategoryAsync(category);
        return category;
    }
}